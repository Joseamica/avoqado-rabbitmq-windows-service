// src/config/index.js
import database from './database.js'
import rabbitmq from './rabbitmq.js'

export default {
  database,
  rabbitmq
}
